﻿using System;
using System.Collections.Generic;

namespace WebBanVeXemPhim.Models;

public partial class Combo
{
    public string? Anh { get; set; }

    public decimal Gia { get; set; }

    public string? TenCombo { get; set; }

    public int MaCombo { get; set; }

}
