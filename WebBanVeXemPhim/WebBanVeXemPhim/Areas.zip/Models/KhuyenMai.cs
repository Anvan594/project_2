﻿using System;
using System.Collections.Generic;

namespace WebBanVeXemPhim.Models;

public partial class KhuyenMai
{
    public string? Anh { get; set; }

    public string? ThongTin { get; set; }

    public bool? TrangThai { get; set; }

    public int MaKhuyenMai { get; set; }
}
