﻿namespace WebBanVeXemPhim.Data
{
    public class XacNhanCode
    {
        public string Email { get; set; }
        public string Code { get; set; }
    }
}
