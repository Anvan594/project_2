﻿namespace WebBanVeXemPhim.Data
{
    public class QuenMatKhau
    {
        string Email { get; set; }
    }
}
